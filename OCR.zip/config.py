from configparser import ConfigParser
import psycopg2

class Database:
    def __init__(self, filename="database.ini", section="postgresql"):
        self.params = self.config(filename, section)
        self.conn = self.connect_to_database()

    def config(self, filename, section):
        parser = ConfigParser()
        parser.read(filename)
        db = {}
        if parser.has_section(section):
            params = parser.items(section)
            for param in params:
                db[param[0]] = param[1]
        else:
            raise Exception(
                'Section {0} is not found in the {1} file.'.format(section, filename))
        return db

    def connect_to_database(self):
        return psycopg2.connect(**self.params)
