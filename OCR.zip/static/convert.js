document.addEventListener('DOMContentLoaded', function () {
    // Fetch data from the server or perform other actions when the page is loaded
    // Example using fetch API:
    fetch('/api/get_results')
        .then(response => response.json())
        .then(data => {
            // Assuming data is an object containing your results
            updateResults(data);
        })
        .catch(error => console.error('Error fetching results:', error));
});

function updateResults(results) {
    // Example: Update the DOM with the results
    const resultContainer = document.getElementById('result-container');

    // Clear existing content
    resultContainer.innerHTML = '';

    // Iterate through results and append to the container
    for (const filename in results) {
        const result = results[filename];

        const resultDiv = document.createElement('div');
        resultDiv.classList.add('result-container');

        const filenameElement = document.createElement('div');
        filenameElement.classList.add('result-filename');
        filenameElement.textContent = result.filename;

        const contentElement = document.createElement('div');
        contentElement.classList.add('result-content');
        contentElement.textContent = result.content;

        resultDiv.appendChild(filenameElement);
        resultDiv.appendChild(contentElement);

        resultContainer.appendChild(resultDiv);
    }
}
