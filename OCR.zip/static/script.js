$(document).ready(function () {
    $('#uploadForm').on('submit', function (e) {
        e.preventDefault();

        var formData = new FormData(this);

        $.ajax({
            type: 'POST',
            url: '/convert',
            data: formData,
            processData: false,
            contentType: false,
            success: function (data) {
                if (data.text) {
                    $('#result').text(data.text);
                } else if (data.error) {
                    $('#result').text('Error: ' + data.error);
                }
            },
            error: function (xhr, status, error) {
                console.error('Error:', error);
            }
        });
    });
});
