from flask import Flask, jsonify, render_template, request
import os
import json
import PIL.Image
from configparser import ConfigParser
from pytesseract import *
import psycopg2

app = Flask(__name__)


class Database:
    def __init__(self, filename="database.ini", section="postgresql"):
        self.params = self.config(filename, section)
        self.conn = self.connect_to_database()

    def config(self, filename, section):
        parser = ConfigParser()
        parser.read(filename)
        db = {}
        if parser.has_section(section):
            params = parser.items(section)
            for param in params:
                db[param[0]] = param[1]
        else:
            raise Exception(
                'Section {0} is not found in the {1} file.'.format(section, filename))
        return db

    def connect_to_database(self):
        return psycopg2.connect(**self.params)

    def create_results_table(self):
        cursor = self.conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS results (
                id SERIAL PRIMARY KEY,
                filename VARCHAR,
                content TEXT,
                timestamp TIMESTAMP,
                ip_address VARCHAR,
                json_result JSONB
            )
        ''')
        self.conn.commit()
        cursor.close()

    def insert_result(self, filename, content, ip_address, json_result):
        cursor = self.conn.cursor()
        cursor.execute(
            "INSERT INTO results (filename, content, timestamp, ip_address, json_result) VALUES (%s, %s, NOW(), %s, %s)",
            (filename, content, ip_address, json_result)
        )
        self.conn.commit()
        cursor.close()


class ImageProcessor:
    def __init__(self):
        # calling pytesseract from directory
        pytesseract.tesseract_cmd = r'C:/Program Files/Tesseract-OCR/tesseract'

    def process_image(self, uploaded_file):
        img = PIL.Image.open(uploaded_file)
        result = pytesseract.image_to_string(img)
        return result


db = Database()


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/convert', methods=['POST'])
def convert():
    uploaded_files = request.files.getlist('file')
    all_results = {}

    for uploaded_file in uploaded_files:
        if uploaded_file.filename != '':
            try:
                result = ImageProcessor().process_image(uploaded_file)
                all_results[uploaded_file.filename] = {'filename': uploaded_file.filename, 'content': result}
            except Exception as e:
                print(f"Error processing file {uploaded_file.filename}: {str(e)}")

    print("All Results:", all_results)

    json_file_name = 'output.json'
    with open(os.path.join('output', json_file_name), 'w') as json_file:
        json.dump(all_results, json_file)

    for result_filename, result_data in all_results.items():
        with open(os.path.join('output', json_file_name), 'r') as json_file:
            json_content = json.load(json_file)
        json_string = json.dumps(json_content, indent=None)

        db.insert_result(result_data['filename'], result_data['content'],
                         request.remote_addr, json_string)

    return json.dumps(all_results, indent=None), 200, {'Content-Type': 'application/json'}





if __name__ == '__main__':
    os.makedirs('uploads', exist_ok=True)
    os.makedirs('output', exist_ok=True)
    db.create_results_table()
    app.run(debug=True)
